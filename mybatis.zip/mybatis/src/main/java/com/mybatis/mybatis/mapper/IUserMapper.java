package com.mybatis.mybatis.mapper;
import com.mybatis.mybatis.entity.User;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.awt.*;
import java.util.List;

@Repository //这个加不加都可以，不加的话，在userService会有报错，但是还是会运行。
public interface IUserMapper {


    User sel(int id);

    List<User> selectByUser(User user);

   int insertUser(User user);

   int deleteUser(User user);

   int updateUser(User user);

   int insertUserList(List<User>list);



}
