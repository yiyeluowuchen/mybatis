package com.mybatis.mybatis.service;

import com.mybatis.mybatis.entity.User;
import com.mybatis.mybatis.mapper.IUserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

import static java.lang.Math.random;

@Service
public class UserService {

    @Autowired
    private IUserMapper userMapper;

    public User sel(Integer id){
        return userMapper.sel(id);
    }

     public List<User> selectByUser(User user){
        return userMapper.selectByUser(user);
     }

     public int insertUser(User user){
       return  userMapper.insertUser(user);
     }

     public int deleteUser(User user){

         return  userMapper.deleteUser(user);
     }

     public int updateUser(User user){

         return userMapper.updateUser(user);
     }

     public int insertUserList(){
    List<User> list=new ArrayList<>();
         User [] user =new User[200];
        for(int i=0;i<50;i++){

           user[i]=new User();
            user[i].setId(i);
            user[i].setUserName("小流"+i*random());
            user[i].setPassword(i+"5");
            user[i].setRealName("小笑"+i);
            list.add(user[i]);
        }
        return userMapper.insertUserList(list);
     }
}
